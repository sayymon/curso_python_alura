
class LanceInvalido(Exception):

    pass